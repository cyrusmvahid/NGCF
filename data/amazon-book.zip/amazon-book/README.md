This is Amazon-book selected from Amazon-review. Amazon-review  is  a  widely  used  dataset  for product recommendation. We use the 10-core setting to ensure that each user and item have at least ten interactions. The dataset is downloaded from the public codes for [Neural Graph Collaborative Filtering](https://github.com/xiangwang1223/neural_graph_collaborative_filtering).

Look for the full dataset? Please visit the [website](http://jmcauley.ucsd.edu/data/amazon).
